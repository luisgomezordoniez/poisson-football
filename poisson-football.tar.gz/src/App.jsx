import { useState, useEffect, useMemo, useCallback } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { loadMatchData, getSeasons, getTeams, getMatches, getAvailableLeagues, LEAGUES } from "./dataLoader.js";
import { MODEL_NAMES, predictMatch, simulateLeague, computeTable, poissonPmf, rpois } from "./models.js";
import T from "./i18n.js";

// ── Theme ──────────────────────────────────────────────────────────
const C = {
  bg: "#0a0f1a", card: "#111827", border: "#1e2d3d",
  accent: "#22d3ee", accentDim: "#0e7490",
  home: "#22d3ee", draw: "#a78bfa", away: "#f472b6",
  text: "#e2e8f0", textDim: "#64748b", textMuted: "#475569",
  success: "#34d399", warning: "#fbbf24",
};

const MAX_GOALS_DISPLAY = 8;

// ── Tiny UI components ─────────────────────────────────────────────
const TabBtn = ({ active, onClick, children }) => (
  <button onClick={onClick} style={{
    padding: "10px 20px", border: "none", background: "transparent",
    borderBottom: active ? `2px solid ${C.accent}` : "2px solid transparent",
    color: active ? C.accent : C.textDim, fontSize: "14px", fontWeight: active ? 600 : 400,
    cursor: "pointer", fontFamily: "'DM Sans',sans-serif", letterSpacing: ".02em", transition: "all .2s",
  }}>{children}</button>
);

const Sel = ({ value, onChange, options, label, style = {} }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 6, ...style }}>
    {label && <label style={{ fontSize: 11, color: C.textDim, textTransform: "uppercase", letterSpacing: ".1em", fontWeight: 600 }}>{label}</label>}
    <select value={value} onChange={e => onChange(e.target.value)} style={{
      padding: "10px 36px 10px 14px", background: C.card, border: `1px solid ${C.border}`,
      borderRadius: 8, color: C.text, fontSize: 14, fontFamily: "'DM Sans',sans-serif",
      cursor: "pointer", outline: "none", appearance: "none",
      backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%2364748b' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10z'/%3E%3C/svg%3E")`,
      backgroundRepeat: "no-repeat", backgroundPosition: "right 12px center",
    }}>
      {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

const Sli = ({ value, onChange, min, max, step, label, display }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
    <div style={{ display: "flex", justifyContent: "space-between" }}>
      <label style={{ fontSize: 11, color: C.textDim, textTransform: "uppercase", letterSpacing: ".1em", fontWeight: 600 }}>{label}</label>
      <span style={{ fontSize: 13, color: C.accent, fontWeight: 600, fontFamily: "'JetBrains Mono',monospace" }}>{display}</span>
    </div>
    <input type="range" min={min} max={max} step={step} value={value}
      onChange={e => onChange(+e.target.value)} style={{ width: "100%", accentColor: C.accent }} />
  </div>
);

// ── Score matrix heatmap ───────────────────────────────────────────
const ScoreMatrix = ({ matrix, homeTeam, awayTeam }) => {
  if (!matrix) return null;
  const flat = matrix.flat();
  const maxV = Math.max(...flat);
  return (
    <div style={{ overflowX: "auto" }}>
      <div style={{ display: "inline-grid", gridTemplateColumns: `56px repeat(${MAX_GOALS_DISPLAY + 1}, 48px)`, gap: 2, fontSize: 11 }}>
        <div style={{ padding: 4, color: C.textDim, textAlign: "center", fontSize: 9 }}>
          {homeTeam?.slice(0,5)}↓\{awayTeam?.slice(0,5)}→
        </div>
        {Array.from({ length: MAX_GOALS_DISPLAY + 1 }, (_, j) => (
          <div key={j} style={{ padding: 4, color: C.accent, textAlign: "center", fontWeight: 700, fontFamily: "'JetBrains Mono',monospace" }}>{j}</div>
        ))}
        {matrix.slice(0, MAX_GOALS_DISPLAY + 1).map((row, i) => [
          <div key={`r${i}`} style={{ padding: 4, color: C.accent, textAlign: "center", fontWeight: 700, fontFamily: "'JetBrains Mono',monospace" }}>{i}</div>,
          ...row.slice(0, MAX_GOALS_DISPLAY + 1).map((p, j) => {
            const t = maxV > 0 ? p / maxV : 0;
            const bg = i > j ? `rgba(34,211,238,${t*.7})` : i < j ? `rgba(244,114,182,${t*.7})` : `rgba(167,139,250,${t*.7})`;
            return <div key={`${i}-${j}`} style={{
              padding: 4, textAlign: "center", background: bg, borderRadius: 4,
              color: t > .3 ? "#fff" : C.textDim, fontFamily: "'JetBrains Mono',monospace",
              fontSize: 10, fontWeight: t > .5 ? 700 : 400,
            }}>{(p * 100).toFixed(1)}</div>;
          })
        ])}
      </div>
    </div>
  );
};

// ── League table ───────────────────────────────────────────────────
const Table = ({ table, t }) => (
  <div style={{ overflowX: "auto" }}>
    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, fontFamily: "'DM Sans',sans-serif" }}>
      <thead><tr style={{ borderBottom: `1px solid ${C.border}` }}>
        <th style={thSt}>#</th><th style={{ ...thSt, textAlign: "left" }}>{t.team}</th>
        {[t.played,t.won,t.drawn,t.lost,t.gf,t.ga,t.gd,t.pts].map(h => <th key={h} style={thSt}>{h}</th>)}
      </tr></thead>
      <tbody>{table.map((r, i) => (
        <tr key={r.team} style={{ borderBottom: `1px solid ${C.border}22`, background: i < 4 ? `${C.accent}08` : "transparent" }}>
          <td style={{ ...tdSt, color: i < 4 ? C.accent : C.textDim, fontWeight: 700, fontFamily: "'JetBrains Mono',monospace" }}>{i + 1}</td>
          <td style={{ ...tdSt, textAlign: "left", color: C.text, fontWeight: 500 }}>{r.team}</td>
          <td style={tdSt}>{r.p}</td>
          <td style={{ ...tdSt, color: C.success }}>{r.w}</td>
          <td style={tdSt}>{r.d}</td>
          <td style={{ ...tdSt, color: C.away }}>{r.l}</td>
          <td style={tdSt}>{r.gf}</td><td style={tdSt}>{r.ga}</td>
          <td style={{ ...tdSt, color: r.gf-r.ga >= 0 ? C.success : C.away, fontFamily: "'JetBrains Mono',monospace" }}>{r.gf-r.ga > 0 ? "+" : ""}{r.gf-r.ga}</td>
          <td style={{ ...tdSt, color: C.accent, fontWeight: 700, fontFamily: "'JetBrains Mono',monospace" }}>{r.pts}</td>
        </tr>
      ))}</tbody>
    </table>
  </div>
);
const thSt = { padding: "10px 8px", textAlign: "center", color: C.textDim, fontWeight: 600, fontSize: 11 };
const tdSt = { padding: "8px", textAlign: "center", color: C.textDim };

// ════════════════════════════════════════════════════════════════════
// MAIN APP
// ════════════════════════════════════════════════════════════════════
export default function App() {
  const [lang, setLang] = useState("en");
  const [data, setData] = useState(null);
  const [tab, setTab] = useState("simulate");
  const [league, setLeague] = useState("E0");
  const [season, setSeason] = useState("");
  const [model, setModel] = useState("Maher");
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [trainPct, setTrainPct] = useState(0.7);
  const [xi, setXi] = useState(0.005);
  const [matchResult, setMatchResult] = useState(null);
  const [simResult, setSimResult] = useState(null);

  const t = T[lang];

  // Load data on mount
  useEffect(() => { loadMatchData().then(setData); }, []);

  // Available leagues & seasons
  const leagueIds = useMemo(() => data ? getAvailableLeagues(data) : [], [data]);
  const seasons = useMemo(() => data ? getSeasons(data, league) : [], [data, league]);
  const matches = useMemo(() => data ? getMatches(data, league, season) : [], [data, league, season]);
  const teams = useMemo(() => data ? getTeams(data, league, season) : [], [data, league, season]);

  // Set default season when league changes
  useEffect(() => {
    if (seasons.length > 0 && !seasons.includes(season)) setSeason(seasons[0]);
  }, [seasons]);

  // Set default teams when teams change
  useEffect(() => {
    if (teams.length >= 2) { setHomeTeam(teams[0]); setAwayTeam(teams[1]); }
    setMatchResult(null); setSimResult(null);
  }, [teams]);

  // Predict match
  const handlePredict = useCallback(() => {
    if (!homeTeam || !awayTeam || homeTeam === awayTeam || !matches.length) return;
    const trainN = Math.floor(matches.length * trainPct);
    const train = matches.slice(0, trainN);
    const result = predictMatch(model, train, homeTeam, awayTeam, { xi });
    setMatchResult(result);
    setSimResult(null);
  }, [homeTeam, awayTeam, model, matches, trainPct, xi]);

  const handleSimulate = useCallback(() => {
    if (!matchResult) return;
    setSimResult({ hg: rpois(matchResult.lambdaH), ag: rpois(matchResult.lambdaA) });
  }, [matchResult]);

  // League tables
  const actualTable = useMemo(() => matches.length ? computeTable(matches) : [], [matches]);
  const predictedTable = useMemo(() =>
    matches.length && teams.length ? simulateLeague(matches, teams, model, trainPct, { xi }) : [],
    [matches, teams, model, trainPct, xi]);

  // Assumption data
  const assumption = useMemo(() => {
    if (!matches.length) return null;
    const hW = matches.filter(m => m.result === "H").length;
    const dW = matches.filter(m => m.result === "D").length;
    const aW = matches.filter(m => m.result === "A").length;
    const hg = matches.map(m => m.hg), ag = matches.map(m => m.ag);
    const mH = hg.reduce((a,b) => a+b,0)/hg.length;
    const mA = ag.reduce((a,b) => a+b,0)/ag.length;
    const vH = hg.reduce((s,g) => s+(g-mH)**2,0)/(hg.length-1);
    const vA = ag.reduce((s,g) => s+(g-mA)**2,0)/(ag.length-1);
    const MG = 6;
    const histH = Array(MG+1).fill(0), histA = Array(MG+1).fill(0);
    hg.forEach(g => histH[Math.min(g,MG)]++);
    ag.forEach(g => histA[Math.min(g,MG)]++);
    const pExpH = Array.from({length:MG+1},(_,k)=> k<MG ? poissonPmf(k,mH)*hg.length : (1-Array.from({length:MG},(_,j)=>poissonPmf(j,mH)).reduce((a,b)=>a+b,0))*hg.length);
    const pExpA = Array.from({length:MG+1},(_,k)=> k<MG ? poissonPmf(k,mA)*ag.length : (1-Array.from({length:MG},(_,j)=>poissonPmf(j,mA)).reduce((a,b)=>a+b,0))*ag.length);
    return {
      results: [{name:t.local,value:hW,color:C.home},{name:t.draw,value:dW,color:C.draw},{name:t.visitor,value:aW,color:C.away}],
      homeGoalDist: Array.from({length:MG+1},(_,i)=>({goals:i===MG?`${MG}+`:`${i}`,observed:histH[i],poisson:Math.round(pExpH[i]*10)/10})),
      awayGoalDist: Array.from({length:MG+1},(_,i)=>({goals:i===MG?`${MG}+`:`${i}`,observed:histA[i],poisson:Math.round(pExpA[i]*10)/10})),
      meanH:mH.toFixed(2), meanA:mA.toFixed(2), varH:vH.toFixed(2), varA:vA.toFixed(2),
      total: matches.length, overdispH: vH > mH*1.3, overdispA: vA > mA*1.3,
    };
  }, [matches, t]);

  const probBars = matchResult ? [
    {name:t.result_home, value:+(matchResult.pHome*100).toFixed(1), color:C.home},
    {name:t.result_draw, value:+(matchResult.pDraw*100).toFixed(1), color:C.draw},
    {name:t.result_away, value:+(matchResult.pAway*100).toFixed(1), color:C.away},
  ] : [];

  // Loading state
  if (!data) return (
    <div style={{ minHeight: "100vh", background: C.bg, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=JetBrains+Mono:wght@400;700&family=Instrument+Serif&display=swap" rel="stylesheet" />
      <div style={{ color: C.accent, fontSize: 18, fontFamily: "'DM Sans',sans-serif" }}>⚽ {t.loading}</div>
    </div>
  );

  return (
    <div style={{ minHeight: "100vh", background: C.bg, color: C.text, fontFamily: "'DM Sans',sans-serif" }}>
      <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=Instrument+Serif&display=swap" rel="stylesheet" />

      {/* ── Header ─────────────────────────────── */}
      <header style={{ padding: "24px 32px", borderBottom: `1px solid ${C.border}`, display: "flex", justifyContent: "space-between", alignItems: "center", background: `linear-gradient(180deg,${C.bg},${C.card})` }}>
        <div>
          <h1 style={{ margin: 0, fontSize: 28, fontFamily: "'Instrument Serif',serif", fontWeight: 400, background: `linear-gradient(135deg,${C.home},${C.draw},${C.away})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            ⚽ {t.title}
          </h1>
          <p style={{ margin: "4px 0 0", fontSize: 13, color: C.textDim }}>{t.subtitle}</p>
        </div>
        <button onClick={() => setLang(l => l === "en" ? "es" : "en")} style={{
          padding: "8px 16px", background: `${C.accent}15`, border: `1px solid ${C.accent}40`,
          borderRadius: 20, color: C.accent, fontSize: 12, fontWeight: 700, cursor: "pointer", letterSpacing: ".1em",
        }}>{t.lang_toggle}</button>
      </header>

      {/* ── Nav ────────────────────────────────── */}
      <nav style={{ display: "flex", gap: 4, padding: "0 32px", borderBottom: `1px solid ${C.border}`, background: C.card, overflowX: "auto" }}>
        {Object.entries(t.tabs).map(([k, v]) => <TabBtn key={k} active={tab===k} onClick={()=>setTab(k)}>{v}</TabBtn>)}
      </nav>

      {/* ── Controls ───────────────────────────── */}
      <div style={{ display: "flex", flexWrap: "wrap", gap: 16, padding: "20px 32px", background: `${C.card}aa`, borderBottom: `1px solid ${C.border}`, alignItems: "flex-end" }}>
        <Sel label={t.league_label} value={league} onChange={setLeague}
          options={leagueIds.map(id => ({ value: id, label: LEAGUES[id]?.[lang] || id }))} style={{ minWidth: 220 }} />
        <Sel label={t.season_label} value={season} onChange={setSeason}
          options={seasons.map(s => ({ value: s, label: s }))} style={{ minWidth: 130 }} />
        <Sel label={t.model_label} value={model} onChange={setModel}
          options={MODEL_NAMES.map(m => ({ value: m, label: m }))} style={{ minWidth: 180 }} />
        <div style={{ minWidth: 160 }}>
          <Sli label={t.train_size} value={trainPct} onChange={setTrainPct} min={0.3} max={1} step={0.1} display={`${Math.round(trainPct*100)}%`} />
        </div>
        {model === "Dixon-Coles TD" && <div style={{ minWidth: 160 }}>
          <Sli label={t.decay_param} value={xi} onChange={setXi} min={0.001} max={0.02} step={0.001} display={xi.toFixed(3)} />
        </div>}
      </div>

      {/* ── Content ─────────────────────────────── */}
      <main style={{ padding: "24px 32px", maxWidth: 1400, margin: "0 auto" }}>

        {/* MATCH SIMULATOR */}
        {tab === "simulate" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr auto 1fr", gap: 16, alignItems: "end", padding: 24, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
              <Sel label={t.home_team} value={homeTeam} onChange={setHomeTeam} options={teams.map(t=>({value:t,label:t}))} />
              <span style={{ fontSize: 24, color: C.textDim, fontWeight: 300, paddingBottom: 8 }}>vs</span>
              <Sel label={t.away_team} value={awayTeam} onChange={setAwayTeam} options={teams.filter(x=>x!==homeTeam).map(t=>({value:t,label:t}))} />
            </div>

            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={handlePredict} style={{ padding: "12px 28px", background: `linear-gradient(135deg,${C.accent},${C.accentDim})`, border: "none", borderRadius: 8, color: "#000", fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'DM Sans',sans-serif" }}>{t.simulate_btn}</button>
              {matchResult && <button onClick={handleSimulate} style={{ padding: "12px 28px", background: `${C.away}20`, border: `1px solid ${C.away}50`, borderRadius: 8, color: C.away, fontSize: 14, fontWeight: 600, cursor: "pointer", fontFamily: "'DM Sans',sans-serif" }}>{t.simulate_match_btn}</button>}
            </div>

            {simResult && matchResult && (
              <div style={{ padding: 20, background: `linear-gradient(135deg,${C.accent}10,${C.away}10)`, borderRadius: 12, border: `1px solid ${C.accent}30`, textAlign: "center" }}>
                <div style={{ fontSize: 12, color: C.textDim, marginBottom: 8, textTransform: "uppercase", letterSpacing: ".1em" }}>{t.sim_result}</div>
                <div style={{ fontSize: 36, fontWeight: 700, fontFamily: "'JetBrains Mono',monospace" }}>
                  <span style={{ color: C.home }}>{homeTeam}</span>
                  <span style={{ color: C.text, margin: "0 16px" }}>{simResult.hg} — {simResult.ag}</span>
                  <span style={{ color: C.away }}>{awayTeam}</span>
                </div>
              </div>
            )}

            {matchResult && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
                {/* Prob bars */}
                <div style={{ padding: 20, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
                  <h3 style={{ margin: "0 0 4px", fontSize: 13, color: C.textDim, textTransform: "uppercase", letterSpacing: ".08em" }}>{t.probability} • {model}</h3>
                  <div style={{ display: "flex", gap: 12, margin: "16px 0" }}>
                    {probBars.map(d => (
                      <div key={d.name} style={{ flex: 1, textAlign: "center" }}>
                        <div style={{ height: 80, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
                          <div style={{ width: "100%", height: `${Math.max(d.value,2)}%`, background: d.color, borderRadius: "6px 6px 0 0", transition: "height .5s" }} />
                        </div>
                        <div style={{ fontSize: 22, fontWeight: 700, color: d.color, fontFamily: "'JetBrains Mono',monospace", marginTop: 8 }}>{d.value}%</div>
                        <div style={{ fontSize: 11, color: C.textDim, marginTop: 2 }}>{d.name}</div>
                      </div>
                    ))}
                  </div>
                  <div style={{ display: "flex", justifyContent: "space-around", padding: "12px 0", borderTop: `1px solid ${C.border}`, marginTop: 12 }}>
                    {[{ label: homeTeam, val: matchResult.lambdaH, color: C.home },
                      { label: t.most_likely, val: `${matchResult.mostLikely[0]} — ${matchResult.mostLikely[1]}`, color: C.draw, sub: `(${(matchResult.mostLikelyProb*100).toFixed(1)}%)` },
                      { label: awayTeam, val: matchResult.lambdaA, color: C.away }
                    ].map((x, i) => (
                      <div key={i} style={{ textAlign: "center" }}>
                        <div style={{ fontSize: 11, color: C.textDim }}>{i !== 1 ? t.expected_goals : t.most_likely}</div>
                        <div style={{ fontSize: 18, fontWeight: 700, color: x.color, fontFamily: "'JetBrains Mono',monospace" }}>
                          {typeof x.val === "number" ? x.val.toFixed(2) : x.val}
                        </div>
                        {x.sub && <div style={{ fontSize: 11, color: C.textDim }}>{x.sub}</div>}
                        {i !== 1 && <div style={{ fontSize: 11, color: C.textDim }}>{x.label}</div>}
                      </div>
                    ))}
                  </div>
                </div>
                {/* Matrix */}
                <div style={{ padding: 20, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
                  <h3 style={{ margin: "0 0 16px", fontSize: 13, color: C.textDim, textTransform: "uppercase", letterSpacing: ".08em" }}>{t.score_matrix}</h3>
                  <ScoreMatrix matrix={matchResult.matrix} homeTeam={homeTeam} awayTeam={awayTeam} />
                </div>
              </div>
            )}

            <div style={{ padding: "16px 20px", background: `${C.accent}08`, borderRadius: 8, borderLeft: `3px solid ${C.accent}40`, fontSize: 13, color: C.textDim, lineHeight: 1.6 }}>
              <strong style={{ color: C.accent }}>{model}:</strong> {t.model_descriptions[model]}
            </div>
          </div>
        )}

        {/* LEAGUE PREDICTOR */}
        {tab === "league" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
            <div style={{ padding: 20, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 14, color: C.accent, fontWeight: 600 }}>{t.predicted_table} — {model}</h3>
              <Table table={predictedTable} t={t} />
            </div>
            <div style={{ padding: 20, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
              <h3 style={{ margin: "0 0 16px", fontSize: 14, color: C.textDim, fontWeight: 600 }}>{t.actual_table}</h3>
              <Table table={actualTable} t={t} />
            </div>
          </div>
        )}

        {/* ASSUMPTIONS */}
        {tab === "assumptions" && assumption && (
          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 20 }}>
              {assumption.results.map(r => (
                <div key={r.name} style={{ padding: 24, background: C.card, borderRadius: 12, border: `1px solid ${C.border}`, textAlign: "center" }}>
                  <div style={{ fontSize: 36, fontWeight: 700, color: r.color, fontFamily: "'JetBrains Mono',monospace" }}>{r.value}</div>
                  <div style={{ fontSize: 12, color: C.textDim, marginTop: 4 }}>{r.name}</div>
                  <div style={{ fontSize: 20, fontWeight: 600, color: r.color, marginTop: 8, fontFamily: "'JetBrains Mono',monospace" }}>{(r.value/assumption.total*100).toFixed(1)}%</div>
                </div>
              ))}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
              {[{ title: t.home_goals, dist: assumption.homeGoalDist, mean: assumption.meanH, vari: assumption.varH, color: C.home, colorDim: `${C.home}60` },
                { title: t.away_goals, dist: assumption.awayGoalDist, mean: assumption.meanA, vari: assumption.varA, color: C.away, colorDim: `${C.away}60` }
              ].map((g, idx) => (
                <div key={idx} style={{ padding: 20, background: C.card, borderRadius: 12, border: `1px solid ${C.border}` }}>
                  <h3 style={{ margin: "0 0 4px", fontSize: 14, color: g.color }}>{g.title}</h3>
                  <p style={{ margin: "0 0 12px", fontSize: 11, color: C.textDim }}>λ̂ = {g.mean} | σ² = {g.vari}</p>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={g.dist} barGap={2}>
                      <XAxis dataKey="goals" tick={{ fill: C.textDim, fontSize: 12 }} axisLine={{ stroke: C.border }} tickLine={false} />
                      <YAxis tick={{ fill: C.textDim, fontSize: 11 }} axisLine={false} tickLine={false} />
                      <Tooltip contentStyle={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: 8, color: C.text, fontSize: 12 }} />
                      <Bar dataKey="observed" fill={g.colorDim} radius={[4,4,0,0]} name={t.observed} />
                      <Bar dataKey="poisson" fill={g.color} radius={[4,4,0,0]} name={t.poisson_expected} />
                      <Legend wrapperStyle={{ fontSize: 11, color: C.textDim }} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              ))}
            </div>
            <div style={{ padding: "16px 20px", background: `${C.warning}08`, borderRadius: 8, borderLeft: `3px solid ${C.warning}40`, fontSize: 13, color: C.textDim, lineHeight: 1.6 }}>
              <strong style={{ color: C.warning }}>{t.dispersion_check}:</strong>{" "}
              {lang === "en"
                ? `Home goals: λ̂=${assumption.meanH}, σ²=${assumption.varH}. Away goals: λ̂=${assumption.meanA}, σ²=${assumption.varA}. ${assumption.overdispH || assumption.overdispA ? t.dispersion_warn : t.dispersion_ok}`
                : `Goles locales: λ̂=${assumption.meanH}, σ²=${assumption.varH}. Goles visitantes: λ̂=${assumption.meanA}, σ²=${assumption.varA}. ${assumption.overdispH || assumption.overdispA ? t.dispersion_warn : t.dispersion_ok}`}
            </div>
          </div>
        )}

        {/* MODELS */}
        {tab === "models" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {MODEL_NAMES.map(m => (
              <div key={m} onClick={() => setModel(m)} style={{
                padding: 24, background: C.card, borderRadius: 12, cursor: "pointer", transition: "all .2s",
                border: `1px solid ${model === m ? C.accent + "60" : C.border}`,
              }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <h3 style={{ margin: 0, fontSize: 18, fontFamily: "'Instrument Serif',serif", color: model === m ? C.accent : C.text }}>{m}</h3>
                  {model === m && <span style={{ padding: "4px 12px", background: `${C.accent}20`, borderRadius: 12, fontSize: 11, color: C.accent, fontWeight: 600 }}>{t.selected}</span>}
                </div>
                <p style={{ margin: "8px 0 0", fontSize: 14, color: C.textDim, lineHeight: 1.6 }}>{t.model_descriptions[m]}</p>
                <div style={{ marginTop: 12, padding: 12, background: `${C.bg}80`, borderRadius: 8, fontSize: 12, color: C.textMuted, fontFamily: "'JetBrains Mono',monospace" }}>
                  {m === "Maher" && "λ_home = α_i × β_j × γ  |  λ_away = α_j × β_i"}
                  {m === "Dixon-Coles" && "P(X=x,Y=y) = τ(x,y,λ,μ,ρ) × Pois(x;λ) × Pois(y;μ)"}
                  {m === "Dixon-Coles TD" && "w_i = exp(-ξ × (t_now - t_i))  |  ξ > 0"}
                  {m === "Bivariate Poisson" && "X = X* + Z, Y = Y* + Z  |  Z ~ Poisson(λ₃)"}
                  {m === "Negative Binomial" && "X ~ NegBin(r,p)  |  E[X] = r(1-p)/p  |  Var[X] > E[X]"}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      <footer style={{ padding: "16px 32px", borderTop: `1px solid ${C.border}`, textAlign: "center", fontSize: 11, color: C.textMuted }}>
        {t.data_source} • {t.built_with} React + Recharts • {t.models_credit}
      </footer>
    </div>
  );
}
