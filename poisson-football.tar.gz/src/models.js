/**
 * models.js
 * 
 * Five football score prediction models:
 *   1. Maher (1982)          — Independent Poisson
 *   2. Dixon-Coles (1997)    — Low-score corrected Poisson
 *   3. Dixon-Coles TD        — Time-decay weighted Dixon-Coles
 *   4. Bivariate Poisson     — Karlis & Ntzoufras (2003)
 *   5. Negative Binomial     — Overdispersion handling
 * 
 * Each model estimates team attack/defense parameters from historical
 * matches, then computes a joint probability matrix P(home=i, away=j)
 * for i,j ∈ {0, 1, ..., MAX_GOALS}.
 */

export const MAX_GOALS = 8;

export const MODEL_NAMES = [
  "Maher",
  "Dixon-Coles",
  "Dixon-Coles TD",
  "Bivariate Poisson",
  "Negative Binomial",
];

// ════════════════════════════════════════════════════════════════════
// Math helpers
// ════════════════════════════════════════════════════════════════════

const _logFactCache = [0, 0];

export function logFactorial(n) {
  if (n < 0) return 0;
  if (n < _logFactCache.length) return _logFactCache[n];
  for (let i = _logFactCache.length; i <= n; i++) {
    _logFactCache[i] = _logFactCache[i - 1] + Math.log(i);
  }
  return _logFactCache[n];
}

export function logGamma(z) {
  if (z < 0.5) return Math.log(Math.PI / Math.sin(Math.PI * z)) - logGamma(1 - z);
  z -= 1;
  const c = [
    0.99999999999980993, 676.5203681218851, -1259.1392167224028,
    771.32342877765313, -176.61502916214059, 12.507343278686905,
    -0.13857109526572012, 9.9843695780195716e-6, 1.5056327351493116e-7
  ];
  let x = c[0];
  for (let i = 1; i < 9; i++) x += c[i] / (z + i);
  const t = z + 7.5;
  return 0.5 * Math.log(2 * Math.PI) + (z + 0.5) * Math.log(t) - t + Math.log(x);
}

export function poissonPmf(k, lambda) {
  if (lambda <= 0) return k === 0 ? 1 : 0;
  return Math.exp(-lambda + k * Math.log(lambda) - logFactorial(k));
}

export function negBinPmf(k, r, p) {
  if (r <= 0 || p <= 0 || p >= 1) return 0;
  return Math.exp(
    logGamma(k + r) - logFactorial(k) - logGamma(r) +
    r * Math.log(p) + k * Math.log(1 - p)
  );
}

/** Draw one sample from Poisson(lambda) */
export function rpois(lambda) {
  if (lambda <= 0) return 0;
  const L = Math.exp(-Math.min(lambda, 500));
  let k = 0, p = 1;
  do { k++; p *= Math.random(); } while (p > L);
  return k - 1;
}

// ════════════════════════════════════════════════════════════════════
// Parameter estimation (iterative scaling MLE)
// ════════════════════════════════════════════════════════════════════

/**
 * Estimate attack, defense, and home advantage parameters.
 * @param {Array} matches - [{home, away, hg, ag}, ...]
 * @param {Array|null} weights - per-match weights (null = uniform)
 * @returns {Object} { teams, teamIdx, attack, defense, homeAdv }
 */
export function estimateParams(matches, weights = null) {
  const teams = [...new Set([...matches.map(m => m.home), ...matches.map(m => m.away)])];
  const n = teams.length;
  const teamIdx = {};
  teams.forEach((t, i) => (teamIdx[t] = i));

  const attack = new Array(n).fill(1.0);
  const defense = new Array(n).fill(1.0);
  let homeAdv = 0.25;

  const w = weights || new Array(matches.length).fill(1);

  // 30 iterations of iterative scaling
  for (let iter = 0; iter < 30; iter++) {
    const aN = new Array(n).fill(0), aD = new Array(n).fill(0);
    const dN = new Array(n).fill(0), dD = new Array(n).fill(0);
    let hgW = 0, agW = 0, mW = 0;

    for (let i = 0; i < matches.length; i++) {
      const m = matches[i];
      const hi = teamIdx[m.home], ai = teamIdx[m.away];
      if (hi === undefined || ai === undefined) continue;
      const wi = w[i];
      const expHA = Math.exp(homeAdv);

      aN[hi] += m.hg * wi;
      aD[hi] += defense[ai] * expHA * wi;
      aN[ai] += m.ag * wi;
      aD[ai] += defense[hi] * wi;

      dN[hi] += m.ag * wi;
      dD[hi] += attack[ai] * wi;
      dN[ai] += m.hg * wi;
      dD[ai] += attack[hi] * expHA * wi;

      hgW += m.hg * wi;
      agW += m.ag * wi;
      mW += wi;
    }

    for (let j = 0; j < n; j++) {
      if (aD[j] > 0) attack[j] = aN[j] / aD[j];
      if (dD[j] > 0) defense[j] = dN[j] / dD[j];
    }

    // Normalize: geometric mean of attack = 1
    const logMean = attack.reduce((s, a) => s + Math.log(Math.max(a, 1e-6)), 0) / n;
    const scale = Math.exp(logMean);
    for (let j = 0; j < n; j++) {
      attack[j] /= scale;
      defense[j] *= scale;
    }

    if (mW > 0) homeAdv = Math.log(Math.max(hgW / agW, 0.5));
  }

  return { teams, teamIdx, attack, defense, homeAdv };
}

// ════════════════════════════════════════════════════════════════════
// Dixon-Coles adjustment factor τ
// ════════════════════════════════════════════════════════════════════

function dcTau(x, y, lH, lA, rho) {
  if (x === 0 && y === 0) return 1 - lH * lA * rho;
  if (x === 0 && y === 1) return 1 + lH * rho;
  if (x === 1 && y === 0) return 1 + lA * rho;
  if (x === 1 && y === 1) return 1 - rho;
  return 1;
}

function estimateRho(matches, params) {
  let adj = 0, count = 0;
  for (const m of matches) {
    const hi = params.teamIdx[m.home], ai = params.teamIdx[m.away];
    if (hi === undefined || ai === undefined) continue;
    if (m.hg <= 1 && m.ag <= 1) {
      adj += (m.hg === 0 && m.ag === 0) ? 1 : (m.hg === 1 && m.ag === 1) ? 1 : -0.5;
      count++;
    }
  }
  return count > 0 ? Math.max(-0.5, Math.min(0.5, adj / (count * 5))) : 0;
}

// ════════════════════════════════════════════════════════════════════
// Bivariate Poisson: P(X=x, Y=y) = Σ_k Pois(x-k;λ1)·Pois(y-k;λ2)·Pois(k;λ3)
// ════════════════════════════════════════════════════════════════════

function bivariatePoissonPmf(x, y, l1, l2, l3) {
  let p = 0;
  const minK = Math.min(x, y);
  for (let k = 0; k <= minK; k++) {
    p += poissonPmf(x - k, l1) * poissonPmf(y - k, l2) * poissonPmf(k, l3);
  }
  return p;
}

function estimateLambda3(matches) {
  const meanH = matches.reduce((s, m) => s + m.hg, 0) / matches.length;
  const meanA = matches.reduce((s, m) => s + m.ag, 0) / matches.length;
  let cov = 0;
  for (const m of matches) cov += (m.hg - meanH) * (m.ag - meanA);
  cov /= Math.max(matches.length - 1, 1);
  return Math.max(0.01, Math.min(0.5, cov > 0 ? cov * 0.3 : 0.05));
}

// ════════════════════════════════════════════════════════════════════
// Negative Binomial dispersion estimation
// ════════════════════════════════════════════════════════════════════

function estimateDispersion(goals, mu) {
  const n = goals.length;
  if (n < 2) return 50;
  const variance = goals.reduce((s, g) => s + (g - mu) ** 2, 0) / (n - 1);
  if (variance <= mu) return 50; // essentially Poisson
  return Math.max(1, (mu * mu) / (variance - mu));
}

// ════════════════════════════════════════════════════════════════════
// Joint probability matrix computation
// ════════════════════════════════════════════════════════════════════

function buildMatrix(lambdaH, lambdaA, type, rho = 0, lambda3 = 0, rH = 50, rA = 50) {
  const matrix = [];
  let pH = 0, pD = 0, pA = 0;

  for (let i = 0; i <= MAX_GOALS; i++) {
    matrix[i] = [];
    for (let j = 0; j <= MAX_GOALS; j++) {
      let p;
      if (type === "negbin") {
        const ppH = rH / (rH + lambdaH);
        const ppA = rA / (rA + lambdaA);
        p = negBinPmf(i, rH, ppH) * negBinPmf(j, rA, ppA);
      } else if (type === "bivariate") {
        p = bivariatePoissonPmf(i, j, lambdaH, lambdaA, lambda3);
      } else {
        p = poissonPmf(i, lambdaH) * poissonPmf(j, lambdaA);
        if (type === "dixoncoles") p *= dcTau(i, j, lambdaH, lambdaA, rho);
      }
      matrix[i][j] = p;
      if (i > j) pH += p;
      else if (i === j) pD += p;
      else pA += p;
    }
  }

  const total = pH + pD + pA || 1;
  pH /= total; pD /= total; pA /= total;

  let maxP = 0, bestI = 0, bestJ = 0;
  for (let i = 0; i <= MAX_GOALS; i++) {
    for (let j = 0; j <= MAX_GOALS; j++) {
      if (matrix[i][j] > maxP) { maxP = matrix[i][j]; bestI = i; bestJ = j; }
    }
  }

  return {
    lambdaH: type === "bivariate" ? lambdaH + lambda3 : lambdaH,
    lambdaA: type === "bivariate" ? lambdaA + lambda3 : lambdaA,
    pHome: pH, pDraw: pD, pAway: pA,
    matrix,
    mostLikely: [bestI, bestJ],
    mostLikelyProb: maxP,
  };
}

// ════════════════════════════════════════════════════════════════════
// Public API: predict a single match
// ════════════════════════════════════════════════════════════════════

/**
 * Predict match outcome probabilities.
 * @param {string} modelName - one of MODEL_NAMES
 * @param {Array} trainMatches - historical matches to train on
 * @param {string} homeTeam
 * @param {string} awayTeam
 * @param {Object} options - { xi: 0.005 } for time decay
 * @returns {Object|null} { lambdaH, lambdaA, pHome, pDraw, pAway, matrix, mostLikely, mostLikelyProb }
 */
export function predictMatch(modelName, trainMatches, homeTeam, awayTeam, options = {}) {
  if (!trainMatches.length) return null;

  let weights = null;
  if (modelName === "Dixon-Coles TD") {
    const xi = options.xi || 0.005;
    const n = trainMatches.length;
    weights = trainMatches.map((_, i) => Math.exp(-xi * (n - i)));
  }

  const params = estimateParams(trainMatches, weights);
  const hi = params.teamIdx[homeTeam];
  const ai = params.teamIdx[awayTeam];
  if (hi === undefined || ai === undefined) return null;

  const lH = Math.max(0.1, params.attack[hi] * params.defense[ai] * Math.exp(params.homeAdv));
  const lA = Math.max(0.1, params.attack[ai] * params.defense[hi]);

  switch (modelName) {
    case "Maher":
      return buildMatrix(lH, lA, "independent");

    case "Dixon-Coles":
    case "Dixon-Coles TD": {
      const rho = estimateRho(trainMatches, params);
      return buildMatrix(lH, lA, "dixoncoles", rho);
    }

    case "Bivariate Poisson": {
      const l3 = estimateLambda3(trainMatches);
      return buildMatrix(Math.max(0.05, lH - l3), Math.max(0.05, lA - l3), "bivariate", 0, l3);
    }

    case "Negative Binomial": {
      const rH = estimateDispersion(trainMatches.map(m => m.hg), lH);
      const rA = estimateDispersion(trainMatches.map(m => m.ag), lA);
      return buildMatrix(lH, lA, "negbin", 0, 0, rH, rA);
    }

    default:
      return buildMatrix(lH, lA, "independent");
  }
}

// ════════════════════════════════════════════════════════════════════
// Public API: simulate a full league season
// ════════════════════════════════════════════════════════════════════

/**
 * Simulate a full league season using the chosen model.
 * Uses actual results for training portion, predicts the rest.
 */
export function simulateLeague(matches, teams, modelName, trainPct, options = {}) {
  const trainN = Math.floor(matches.length * trainPct);
  const trainMatches = matches.slice(0, trainN);

  let weights = null;
  if (modelName === "Dixon-Coles TD") {
    const xi = options.xi || 0.005;
    weights = trainMatches.map((_, i) => Math.exp(-xi * (trainN - i)));
  }

  const params = estimateParams(trainMatches, weights);
  const n = teams.length;
  const predicted = [];

  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i === j) continue;
      const existing = trainMatches.find(m => m.home === teams[i] && m.away === teams[j]);
      if (existing) {
        predicted.push({ ...existing });
      } else {
        const pred = predictMatch(modelName, trainMatches, teams[i], teams[j], options);
        if (pred) {
          const hg = Math.round(pred.lambdaH);
          const ag = Math.round(pred.lambdaA);
          predicted.push({
            home: teams[i], away: teams[j], hg, ag,
            result: hg > ag ? "H" : hg < ag ? "A" : "D",
          });
        }
      }
    }
  }

  return computeTable(predicted);
}

/**
 * Compute league standings from a list of matches.
 */
export function computeTable(matches) {
  const tbl = {};
  for (const m of matches) {
    if (!tbl[m.home]) tbl[m.home] = { team: m.home, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 };
    if (!tbl[m.away]) tbl[m.away] = { team: m.away, p: 0, w: 0, d: 0, l: 0, gf: 0, ga: 0, pts: 0 };

    tbl[m.home].p++; tbl[m.away].p++;
    tbl[m.home].gf += m.hg; tbl[m.home].ga += m.ag;
    tbl[m.away].gf += m.ag; tbl[m.away].ga += m.hg;

    if (m.hg > m.ag) { tbl[m.home].w++; tbl[m.home].pts += 3; tbl[m.away].l++; }
    else if (m.hg < m.ag) { tbl[m.away].w++; tbl[m.away].pts += 3; tbl[m.home].l++; }
    else { tbl[m.home].d++; tbl[m.home].pts++; tbl[m.away].d++; tbl[m.away].pts++; }
  }

  return Object.values(tbl).sort((a, b) => b.pts - a.pts || (b.gf - b.ga) - (a.gf - a.ga) || b.gf - a.gf);
}
